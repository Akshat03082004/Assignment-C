#include <stdio.h>
int main()
{
    int a ,b,temp;
    printf("enter the values");
    scanf("%d %d",&a,&b);
    printf("the values of a=%d and b=%d",a,b);
    temp=a;
    a=b;
    b=temp;
    printf("\n New values are a=%d and b=%d",a,b);
}