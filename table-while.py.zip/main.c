

#include <stdio.h>

int main()
{
    int num,n2=1;
    printf("Enter num \n");
    scanf("%d",&num);
    while (n2<=10){
      printf("%d*%d=%d\n",num,n2,num*n2);
        n2=n2+1;}
    }
    

